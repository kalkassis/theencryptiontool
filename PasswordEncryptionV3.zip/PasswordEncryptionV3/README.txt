                            *********************************The Encryption Tool *********************************
                            *********************************   By: Khalil A     *********************************

                                                FOR PERSONAL USE ONLY, MEANT FOR DEMO PURPOSES


Summary:

The Encryption Tool depends on a key file, ''key.txt'' (can be renamed but the program only looks for a text file with this exact name), 
automatically generated on first launch or when the file is not found within the immediate directory of the program. Each key is totally 
unique upon creation and is used for encryption/decryption by the user, it is recommended to be stored in a separate location, such as 
cloud storage when usage is over for later use. A set of options is presented for the user to choose from.

How To:

Execute the program and a key.txt file will be generated, you will then be prompted to close the program and re-open it into Encryption/
Decryption mode, from there you are given options to choose from to move forward.

When you're done using the program, the key.txt file (or its contents) can be moved anywhere for safe keeping and paired with the program 
later on, by copy/paste or dragging the key.txt file into the same directory as the main Encryption Tool.

The tool itself is totally portable, just the .exe is needed to run if no existing key file has been created.


